public class HelloGoodbye {
    public static void main(String[] args) {
        String a = args[0];
        String b = args[1];
        System.out.println("Hello " + a + " and " + b + ".");
        System.out.println("Goodbye " + b + " and " + a + ".");
    }
}
